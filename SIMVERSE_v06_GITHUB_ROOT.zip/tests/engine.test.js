const assert=require('node:assert/strict');const S=require('../engine.js');
const EPS=1e-7;
function club(team){return S.nbaRoster(Array.from({length:13},(_,i)=>({name:`${team} Athlete ${i}`,team,id:`${team}-${i}`,position:i%5===4?'C':i%5>=3?'F':'G',jersey:String(i+1),last3PreseasonMinutes:[16+i%12,18+i%12,20+i%12],box:{games:3,minutes:66+3*i,fga:25+3*i,fgm:10+i,fg3a:12,fg3m:4,reb:10,ast:9,stl:2,blk:1}})));}
let A=club('A'),B=club('B');assert.equal(A.length,13);
const guard=S.nbaProfile({name:'Guard',position:'G',last3PreseasonMinutes:[20,25,30],box:{games:3,minutes:75,fga:30,fgm:14,fg3a:19,fg3m:7,reb:8,ast:15}});
const big=S.nbaProfile({name:'Big',position:'C',last3PreseasonMinutes:[20,25,30],box:{games:3,minutes:75,fga:30,fgm:14,fg3a:0,fg3m:0,reb:30,ast:4}});
assert(guard.three>big.three,'Guards with many threes should attempt threes more often');assert(big.rebound>guard.rebound);
const noData=S.nbaProfile({name:'Unknown',position:'G'});assert.equal(noData.statsSupported,false);assert.match(noData.quality,/UNKNOWN/);
const cap=S.nbaRoster([{name:'Capped',id:'star',position:'G',minutesCap:14,box:{games:3,minutes:60,fga:33},last3PreseasonMinutes:[22,20,18]}],'preseason','B');assert(cap.find(x=>x.name==='Capped').projectedMinutes<=14);
const game=S.makeNBAGame([A,B],{phase:'preseason',scenario:'B'});const r=S.rng(141);
for(let i=0;i<400&&!game.ended;i++){let p=S.nbaPlay(game,r);assert(p.shooter&&p.defender&&p.handler);S.commitNBA(game,p);}
assert(game.ended,'Full game should end');assert(game.q>=4);assert(game.score.every(x=>x>=0));assert.equal(game.score.reduce((x,y)=>x+y,0),Object.values(game.playerStats).reduce((a,x)=>a+x.pts,0),'Player scoring must equal team scoring');
const m=S.runMonteCarlo('NBA',[A,B],{phase:'regular',scenario:'B',seed:123},1000);assert.equal(m.runs,1000);assert(Math.abs(m.awayPct+m.homePct+m.drawPct-100)<EPS);assert(m.total.p10<=m.total.p50 && m.total.p50<=m.total.p90);
function bat(team){return Array.from({length:9},(_,i)=>({name:team+' Batter '+(i+1),id:`${team}-${i}`,position:i%3?'OF':'IF',stats:{atBats:480,plateAppearances:550,avg:.257,baseOnBalls:49,strikeOuts:112,homeRuns:14,doubles:25}}));}
const rr=[bat('A'),bat('H')],mlb=S.makeMLBGame(rr,{phase:'playoffs',scenario:'B'});const r2=S.rng(890);
for(let i=0;i<260&&!mlb.ended;i++){const p=S.mlbAtBat(mlb,r2);S.commitMLB(mlb,p,r2);}
assert(mlb.ended,'MLB game should eventually finish');assert(mlb.inning>=9);assert(mlb.score[0]!==mlb.score[1]);
assert.equal(S.advanceBases([{name:'1'},{name:'2'},{name:'3'}],'walk',{name:'B'},()=>.5).runs.length,1,'Bases-loaded walk scores one run');
assert.equal(S.advanceBases([{name:'1'},{name:'2'},{name:'3'}],'homer',{name:'B'},()=>.5).runs.length,4,'Grand slam scores four');
const m2=S.runMonteCarlo('MLB',rr,{phase:'playoffs',seed:123},1000);assert.equal(m2.runs,1000);assert(Math.abs(m2.awayPct+m2.homePct+m2.drawPct-100)<EPS);
console.log('PASS: named NBA players, sample shrinkage, minute caps, scoreboard consistency, MLB baserunners, walk-offs, and 2x1,000 Monte Carlo runs.');
