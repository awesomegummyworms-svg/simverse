import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from player_data import parse_nba_roster, parse_nba_box_minutes, parse_prior_nba_season
from update_data import mlb_phase, nba_phase, parse_mlb_lineup,local_date

class SourceIntegrityTests(unittest.TestCase):
    def test_nba_roster_real_identity_and_missing_stats(self):
        data={'athletes':[{'id':'88','displayName':'Example Player','position':{'abbreviation':'PG'},'jersey':'14','headshot':{'href':'https://example.org/headshot.png'},'injuries':[{'status':'Day-To-Day'}]}]}
        rows=parse_nba_roster(data,'BOS')
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['name'],'Example Player')
        self.assertIsNone(rows[0]['box'])
        self.assertEqual(rows[0]['availability'],'injury listed — status requires verification')

    def test_preseason_minutes_from_reported_box(self):
        src={'boxscore':{'players':[{'statistics':[{'labels':['MIN','FG','3PT','FT','REB','AST','STL','BLK','TO'],'athletes':[{'athlete':{'id':'11','displayName':'Reported Athlete'},'starter':True,'stats':['18:30','5-12','2-5','4-6','7','3','1','2','2']}]}]}]}}
        parsed=parse_nba_box_minutes(src)
        self.assertAlmostEqual(parsed['11']['minutes'],18.5)
        self.assertEqual(parsed['11']['fg3a'],5)
        self.assertEqual(parsed['11']['ast'],3)

    def test_season_stats_are_previous_regular_season_only(self):
        stats={'categories':[{'labels':['GP','MIN','FG','3PT','AST','REB','STL','BLK','FTA'],'totals':['60','31.8','8.0-17.0','2.7-7.1','6.1','4.2','1.0','.3','3.5']}]}
        info=parse_prior_nba_season(stats)
        self.assertIsNotNone(info)
        self.assertEqual(info['season'],2026)
        self.assertEqual(info['seasonType'],'2025-26 regular season, previous-year prior')
        self.assertEqual(info['fg3a'],7.1)

    def test_phases(self):
        self.assertEqual(mlb_phase('R'),'regular')
        self.assertEqual(mlb_phase('D'),'playoffs')
        self.assertEqual(nba_phase({'season':{'type':1}}),'preseason')
        self.assertEqual(nba_phase({'season':{'type':3}}),'playoffs')
        self.assertEqual(nba_phase({'season':{}}),'unknown')

    def test_mlb_lineup_only_confirmed_with_nine_slots(self):
        players={f'ID{i}':{'person':{'fullName':f'Player {i}'},'battingOrder':f'{i}00','position':{'abbreviation':'OF'}} for i in range(1,10)}
        parsed=parse_mlb_lineup({'teams':{'away':{'players':players}}},'away')
        self.assertEqual(parsed['status'],'confirmed')
        self.assertEqual(len(parsed['players']),9)
        del players['ID9']
        self.assertEqual(parse_mlb_lineup({'teams':{'away':{'players':players}}},'away')['status'],'pending')

    def test_melbourne_date_boundary(self):
        self.assertEqual(local_date('2026-10-10T23:00:00Z'),'2026-10-11')

if __name__=='__main__':unittest.main()
