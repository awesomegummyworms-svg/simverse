#!/usr/bin/env python3
"""Build self-contained static site for GitHub Pages Actions."""
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
out=root/'site'
if out.exists():shutil.rmtree(out)
(out/'assets').mkdir(parents=True)
(out/'data').mkdir(parents=True)
for item in ['index.html','styles.css','engine.js','app.js','sim_worker.js','.nojekyll']:
    shutil.copy2(root/item,out/item)
shutil.copy2(root/'assets'/'command-hq.webp',out/'assets'/'command-hq.webp')
shutil.copy2(root/'data'/'snapshot.json',out/'data'/'snapshot.json')
print('Built SIMVERSE v0.6 public site at:',out)
