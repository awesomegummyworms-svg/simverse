"""Data adapter — actual roster identities + small-sample recent NBA minutes/box scores.
No athlete receives invented per-player performance statistics. Any missing stat remains null.
ESPN endpoints are unofficial; availability and reuse terms must be reviewed by deployer.
"""
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.parse
from pathlib import Path
import json

NBA_ABBR={'GS':'GSW','SA':'SAS','NY':'NYK','NO':'NOP','NOR':'NOP','PHO':'PHX','UTAH':'UTA','WSH':'WAS','BKN':'BKN'}
MLB_MAP={'ARI':109,'ATL':144,'ATH':133,'BAL':110,'BOS':111,'CHC':112,'CHW':145,'CIN':113,'CLE':114,'COL':115,'DET':116,'HOU':117,'KCR':118,'LAA':108,'LAD':119,'MIA':146,'MIL':158,'MIN':142,'NYM':121,'NYY':147,'PHI':143,'PIT':134,'SDP':135,'SEA':136,'SFG':137,'STL':138,'TBR':139,'TEX':140,'TOR':141,'WSN':120}

def nba_ids(get_json):
    feed=get_json('https://site.api.espn.com/apis/site/v2/sports/basketball/nba/teams')
    clubs=((feed.get('sports') or [{}])[0].get('leagues') or [{}])[0].get('teams') or []
    out={}
    for item in clubs:
        t=item.get('team') or item
        key=NBA_ABBR.get(str(t.get('abbreviation','')).upper(),str(t.get('abbreviation','')).upper())
        if key and t.get('id'):out[key]=str(t['id'])
    return out

def parse_nba_roster(feed,team):
    people=feed.get('athletes') or []
    flat=[]
    for p in people:
        if isinstance(p,dict) and isinstance(p.get('items'),list):flat.extend(p['items'])
        elif isinstance(p,dict):flat.append(p)
    rows=[]
    for p in flat:
        if not p.get('id') or not p.get('displayName'):continue
        inj=p.get('injuries') or []
        availability='unknown'
        if inj and isinstance(inj[0],dict):availability='injury listed — status requires verification'
        rows.append({'id':str(p['id']),'name':str(p['displayName'])[:100],'team':team,
          'jersey':str(p.get('jersey',''))[:4], 'position':(p.get('position') or {}).get('abbreviation','G'),
          'height':p.get('height'), 'headshot':(p.get('headshot') or {}).get('href'),
          'availability':availability,'seasonMinutes':None,'box':None,'last3PreseasonMinutes':[],
          'dataSource':'ESPN reported team roster; individual performance not yet available'})
    return rows

def parse_nba_box_minutes(summary):
    """Aggregate ESPN summary player stats; parse exact labelled columns only."""
    observed={}
    for group in (summary.get('boxscore') or {}).get('players',[]):
        stats=group.get('statistics') or []
        for stat in stats:
            keys=[str(x).upper() for x in (stat.get('labels') or stat.get('names') or [])]
            for row in stat.get('athletes') or []:
                athlete=row.get('athlete') or {}
                aid=str(athlete.get('id') or '')
                if not aid:continue
                data=row.get('stats') or []
                if isinstance(data,dict): line={str(k).upper():v for k,v in data.items()}
                else:line=dict(zip(keys,data))
                minutes=str(line.get('MIN','')).strip()
                try:
                    if ':' in minutes:
                        aa,bb=minutes.split(':',1);mins=float(aa)+float(bb)/60
                    else:mins=float(minutes)
                except (ValueError,TypeError):continue
                if not (0<=mins<=65):continue
                def number(k,default=0):
                    try:return float(line.get(k,default))
                    except (ValueError,TypeError):return default
                def split(k):
                    try: v=str(line.get(k,'0-0')).split('-');return float(v[0]),float(v[1])
                    except (ValueError,TypeError,IndexError):return (0,0)
                fgm,fga=split('FG');fg3m,fg3a=split('3PT');ftm,fta=split('FT')
                observed[aid]={'minutes':round(mins,2),'fga':fga,'fgm':fgm,'fg3a':fg3a,'fg3m':fg3m,'fta':fta,'ftm':ftm,
                   'reb':number('REB'),'ast':number('AST'),'stl':number('STL'),'blk':number('BLK'),'tov':number('TO')}
    return observed

def recent_nba_boxscores(get_json,today,team_ids,errors):
    start=(today-timedelta(days=24)).strftime('%Y%m%d');end=today.strftime('%Y%m%d')
    try:feed=get_json(f'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard?dates={start}-{end}&limit=500')
    except Exception as exc:errors.append('NBA recent minutes: '+str(exc)[:130]);return {}
    completed=[]
    for event in feed.get('events',[]):
        if (event.get('season') or {}).get('type') != 1:continue
        if (((event.get('status') or {}).get('type') or {}).get('state')) != 'post':continue
        if event.get('id'):completed.append((event.get('date',''),str(event['id'])))
    # Only near-term completed preseason fixtures. Preserve reported event dates.
    completed=sorted(completed,reverse=True)[:36];stats_by_player=defaultdict(list)
    event_dates={ev:dt for dt,ev in completed}
    def task(ev):return ev,get_json(f'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/summary?event={ev}')
    with ThreadPoolExecutor(max_workers=7) as pool:
        futures={pool.submit(task,ev):ev for _,ev in completed}
        for fut in as_completed(futures):
            try: ev,box=fut.result()
            except Exception:continue
            for aid,row in parse_nba_box_minutes(box).items():stats_by_player[aid].append((ev,row))
    profiles={}
    for aid,seen in stats_by_player.items():
        # Sort by reported date, not ID or concurrent request completion order.
        arr=[v for _,v in sorted(seen,key=lambda x:(event_dates.get(x[0],''),x[0]),reverse=True)[:3]]
        if not arr:continue
        aggregate={key:round(sum(x.get(key,0) for x in arr),3) for key in ['minutes','fga','fgm','fg3a','fg3m','fta','ftm','reb','ast','stl','blk','tov']}
        aggregate['games']=len(arr)
        profiles[aid]={'box':aggregate,'last3PreseasonMinutes':[x['minutes'] for x in arr]}
    return profiles

def mlb_roster(get_json,team,season):
    ident=MLB_MAP[team]
    url=f'https://statsapi.mlb.com/api/v1/teams/{ident}/roster?rosterType=active&season={season}'
    raw=get_json(url)
    rows=[]
    for row in raw.get('roster',[]):
        person=row.get('person') or {};pid=person.get('id')
        if not pid:continue
        pos=(row.get('position') or {}).get('abbreviation','')
        rows.append({'id':str(pid),'name':str(person.get('fullName','Unknown'))[:100],'team':team,
                     'position':pos, 'jersey':str(row.get('jerseyNumber','')),
                     'headshot':f'https://img.mlbstatic.com/mlb-photos/image/upload/w_180,q_auto:best/v1/people/{pid}/headshot/67/current',
                     'stats':None,'availability':'unknown','dataSource':'MLB StatsAPI active roster; performance not supplied'})
    return rows

def mlb_hitter_stats(get_json,team,season):
    """Optional team stats endpoint. If payload schema differs, do not invent stats."""
    ident=MLB_MAP[team]
    url=f'https://statsapi.mlb.com/api/v1/stats?stats=season&group=hitting&teamId={ident}&sportIds=1&season={season}&limit=60'
    raw=get_json(url);out={}
    for section in raw.get('stats',[]):
        for sp in section.get('splits',[]):
            player=sp.get('player') or {};pid=player.get('id');stat=sp.get('stat') or {}
            if pid and stat.get('plateAppearances'):
                out[str(pid)]={'plateAppearances':stat.get('plateAppearances'),'atBats':stat.get('atBats'), 'avg':stat.get('avg'), 'baseOnBalls':stat.get('baseOnBalls'), 'homeRuns':stat.get('homeRuns'), 'doubles':stat.get('doubles'), 'strikeOuts':stat.get('strikeOuts')}
    return out

def build_player_index(games,get_json,now,errors):
    lookup={'NBA':{},'MLB':{}}
    cache_path=Path(__file__).resolve().parents[1]/'data'/'profile_cache.json'
    try:cache=json.loads(cache_path.read_text()).get('NBA',{})
    except (OSError,ValueError,TypeError):cache={}
    teams={'NBA':set(),'MLB':set()}
    # Initial profile hydration is bounded per refresh and progresses through uncached athletes.
    # It prevents hundreds of outbound requests and keeps scheduled workflow duration practical.
    profile_budget={'remaining':60}
    for game in games:
        if game.get('sourceState')=='stale':continue
        teams[game['sport']].update([game['away'],game['home']])
    if teams['NBA']:
        try:ids=nba_ids(get_json)
        except Exception as exc:ids={};errors.append('NBA team lookup: '+str(exc)[:160])
        stats=recent_nba_boxscores(get_json,now.date(),ids,errors) if ids else {}
        for club in sorted(teams['NBA']):
            if club not in ids:continue
            try:
                players=parse_nba_roster(get_json(f'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/teams/{ids[club]}/roster'),club)
                for p in players:
                    recent=stats.get(p['id'])
                    if recent:p.update(recent);p['dataSource']='ESPN roster + last preseason box scores (1–3 observed games)'
                players=update_prior_seasons(players,get_json,cache,errors,profile_budget)
                lookup['NBA'][club]={'players':players,'source':'ESPN roster + NBA previous-season stats (where available) + preseason box scores','observedAt':now.isoformat()}
            except Exception as exc:errors.append('NBA '+club+' roster: '+str(exc)[:140])
    if teams['MLB']:
        for club in sorted(teams['MLB']):
            try:
                players=mlb_roster(get_json,club,now.year)
                try:st=mlb_hitter_stats(get_json,club,now.year)
                except Exception:st={}
                for p in players:
                    if p['id'] in st:p['stats']=st[p['id']];p['dataSource']='MLB StatsAPI roster + season hitting stats'
                lookup['MLB'][club]={'players':players,'source':'MLB StatsAPI active roster and available hitting stats','observedAt':now.isoformat()}
            except Exception as exc:errors.append('MLB '+club+' roster: '+str(exc)[:140])
    cache_path.write_text(json.dumps({"NBA":cache},indent=2)+"\n",encoding="utf-8")
    return lookup

def parse_prior_nba_season(raw):
    """ESPN web-v3 *previous regular season* statistics; never mislabeled preseason."""
    stats={}
    for group in raw.get('categories', []):
        labels=group.get('labels') or []
        for row in [group.get('totals') or []]:
            for label,val in zip(labels,row):
                key=str(label).strip().upper().replace('%','PCT')
                if key not in stats and val is not None:
                    stats[key]=val
    def numeric(*keys):
        for k in keys:
            v=stats.get(k)
            try:return float(str(v).replace(',',''))
            except (ValueError,TypeError):continue
        return None
    gp=numeric('GP');mpg=numeric('MIN','MPG');
    if not gp or gp<5 or not mpg:return None
    out={'games':int(gp),'mpg':mpg}
    for target,names in {
      'fgm':['FGM'],'fga':['FGA'],'fg3m':['3PM','3PTM','FG3M'],'fg3a':['3PA','3PTA','FG3A'],
      'fta':['FTA'],'ast':['AST'],'reb':['REB'],'stl':['STL'],'blk':['BLK']}.items():
        v=numeric(*names)
        if v is not None:out[target]=v
    # ESPN sometimes reports per-game pairs e.g. "8.7-17.9" under FG and 3PT.
    for key,made,att in [('FG','fgm','fga'),('3PT','fg3m','fg3a'),('FT','ftm','fta')]:
        if made in out and att in out:continue
        try:
            lhs,rhs=str(stats.get(key,'')).split('-',1)
            out[made]=float(lhs);out[att]=float(rhs)
        except (ValueError,TypeError):pass
    if not out.get('fga'):return None
    out['season']=2026
    out['seasonType']='2025-26 regular season, previous-year prior'
    return out

def update_prior_seasons(players,get_json,cache,errors,budget=None):
    pending=[p for p in players if str(p['id']) not in cache]
    if budget is not None:
        allowed=max(0,int(budget.get('remaining',0)))
        pending=pending[:allowed]
        budget['remaining']=allowed-len(pending)
    def task(p):
        uri='https://site.web.api.espn.com/apis/common/v3/sports/basketball/nba/athletes/'+str(p['id'])+'/stats?season=2026&seasontype=2'
        return str(p['id']),parse_prior_nba_season(get_json(uri))
    with ThreadPoolExecutor(max_workers=7) as pool:
        futures={pool.submit(task,p):p for p in pending}
        for fut in as_completed(futures):
            pid=str(futures[fut]['id'])
            try: _,stat=fut.result();cache[pid]=stat or {}
            except Exception as exc:
                # Missing stats are kept missing, but network failures should be retried on the next scheduled run.
                errors.append('NBA previous season '+pid+': '+str(exc)[:60])
    for p in players:
        st=cache.get(p['id']) or None
        if st:
            p['seasonStats']=st;p['seasonMinutes']=st['mpg']
            p['dataSource'] += ' + ESPN 2025-26 regular-season baseline'
    return players
